#include<stdio.h>
#include <stdlib.h>

#define SENT_LEN 100
struct word_info{
  char arr[20];
  int freq;
};



struct word_info *list;
//struct sparse_matrix *sp_matrix;
int num_words;
int size = 0;
extern void update_list(int n1,int n2,float wt);

int getindex(char *a)
{
  int i;
  for(i=0;i<num_words;i++)
    {
      if(strcmp(list[i].arr,a) == 0)
	{
	  //printf("return %d %s\n",i,list[i].arr);
	  return i;
	}
    }
  return -1;
}


int main(int argc,char *argv[])
{
  FILE *fp,*fp1;
  int i =0,j=0,k=0,count=0;
  char c,word[SENT_LEN][40];
  int ind1,ind2;
  
  printf("%s %s %d\n",argv[1],argv[2],argc);
  fp = fopen(argv[1],"r");
  fp1 = fopen(argv[2],"r");
  if( fp == NULL || fp1 == NULL)printf("error\n");
  
  
  printf("how many words u want to pick up\n");
  scanf("%d",&num_words);
  
  list = (struct word_info *)malloc(num_words*sizeof(struct word_info));
  if(list == NULL)printf("error2\n");
  i=0;
  while(!feof(fp) && i < num_words )
    {
      fscanf(fp,"%d",&list[i].freq);
      fscanf(fp,"%s",&list[i].arr);
      i++;

      if((c= fgetc(fp)) != EOF)
	ungetc(c,fp);
    }
  //printf("--%d\n",list[i-1].freq);
  //  for(i=0;i<num_words;i++)printf("%d %s\n",list[i].freq,list[i].arr);
  
  while(!feof(fp1))
    {
      //printf("numLine= %d\n",count++);
      
      for(i=0;i<SENT_LEN;i++)
	{
	  fscanf(fp1,"%s\n",word[i]);
	  //printf("%s,%d\n",word[i],i);//getchar();
	  if(strcmp(word[i],"<end>") == 0)break;
	  /*while((c= fgetc(fp)) != EOF)
	    ungetc(c,fp)*/
	}
      
      if(i==SENT_LEN)
	{
	  while(strcmp(word[i-1],"<end>") != 0)
	    fscanf(fp1,"%s\n",word[i-1]);
	  continue;
	}
      
	
	
      for(j=0;j<i-1;j++)
	{
	
	  if((ind1  = getindex(word[j])) != -1)
	     for(k=j+1;k<i;k++)
	       {
			
		 if((ind2 = getindex(word[k])) != -1)
		   {	 
			//printf("%d %d\n",ind1,ind2);getchar();
		     if(ind1 < ind2)
		       update_list(ind1,ind2,(1/(float)(k-j)));
		     else
		       update_list(ind2,ind1,(1/(float)(k-j)));
		   }
	       }
	     
	}


	//printf("+++++\n");
	if((c=fgetc(fp1)) != EOF)ungetc(c,fp1);
    }


  fclose(fp);
  fclose(fp1);
  printnodes("engedges");

}





