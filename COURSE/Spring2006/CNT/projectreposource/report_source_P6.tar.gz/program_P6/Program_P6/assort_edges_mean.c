#include<stdio.h>

int main()
{
FILE *fp1,*fp2;
//int adjMat[10000][10000] = {0};
int degrees[10000] = {0} ;
float assort[10000][2];
int i;
int vert1,vert2;
float wt;

fp1 = fopen("eng_deg_th_eq0.000000","r");   //name of the degree file
fp2 = fopen("engedges","r");   //name of the edges file

if(fp1 == NULL || fp2 == NULL)
printf("unable to open the file \n");

for(i=0;i<10000;i++)    //store the degres in an array
fscanf(fp1,"%d",&degrees[i]);

while(!feof(fp2))
{
	fscanf(fp2,"%d %d %f",&vert1,&vert2,&wt);
//	adjMat[row][col] = adjMat[col][row] = 1;
	assort[vert1][0] += wt;
	assort[vert1][1]++;
	assort[vert2][0] += wt;
	assort[vert2][1]++;

}

for(i=0;i<10000;i++)
{
	if(assort[i][1] != 0)
	printf("%d %f\n",i,(float)assort[i][0]/(float)assort[i][1]);
	else printf("%d node has no neighbour\n",i);


}

fclose(fp1);
fclose(fp2);

}
