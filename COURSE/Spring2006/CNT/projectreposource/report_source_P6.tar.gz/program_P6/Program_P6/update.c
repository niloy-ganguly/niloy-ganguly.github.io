#include <stdio.h>
#include <stdlib.h>

struct edge{
int n1;
int n2;
float wt;
struct edge *next;
struct edge *nex_1;
};

struct edge *ntwk,*new;




void update_list(int n1,int n2,float wt)
{
	struct edge *t1,*t2,*temp;
	//printf("-- %d %d %f\n",n1,n2,wt);

	if(ntwk==NULL){
		ntwk=(struct edge *)malloc(sizeof(struct edge)); 
		if(ntwk==NULL)printf("error in 1st malloc\n");
		ntwk->n1=n1;
		ntwk->n2=n2;
		ntwk->wt=wt;
		return;
	}
	else {
		t1=ntwk;
		while(t1!=NULL){
			t2=t1;
			if(t1->n1==n1)break;
			t1=t1->nex_1;
		}

		if(t1==NULL){
			new=(struct edge *)malloc(sizeof(struct edge));
			if(new==NULL)printf("error in malloc\n");
			t2->nex_1=new;
			new->n1=n1;
			new->n2=n2;
			new->wt=wt;
			return;
		}
		else {
			while(t1!=NULL){
				t2=t1;
				if(t1->n2==n2)
				{
					t1->wt+=wt;
					return;
				}
				t1=t1->next;
			}
			if(t1==NULL){
				new=(struct edge *)malloc(sizeof(struct edge));
				if(new==NULL)printf("error in malloc\n");
				t2->next=new;
				new->n1=n1;
				new->n2=n2;
				new->wt=wt;
				return;
			}
			
		}
	}	
}

printnodes(char str[])
{
	FILE *fp=fopen(str,"w");
	struct edge *t1,*t2,*temp;
	t1=ntwk;
	t2=ntwk;
	while(t1!=NULL){
		while(t2!=NULL)
		{
			fprintf(fp,"%d %d %f\n",t2->n1,t2->n2,t2->wt);
			t2=t2->next;
		}
		t1=t1->nex_1;
		t2=t1;
	}
}	



