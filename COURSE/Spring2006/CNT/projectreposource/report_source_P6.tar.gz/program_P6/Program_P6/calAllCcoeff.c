#include <stdio.h>
#define NUM_VERT 10000
#define NUM_EDGES 1000000

int main()
{
	FILE *fp;
	int i,j,vertex,edge,vert[NUM_VERT]={0},count_nbr=0,count_trng=0;
	float scanWt;
	int scanNode[2];
	char fName[30],c;
	//printf("input Edges file\n");
	scanf("%s",fName);
	for(vertex=0;vertex<4000;vertex++){
	for(i=0;i<NUM_VERT;i++)vert[i]=0;
	count_nbr=0;
	count_trng=0;
	fp=fopen(fName,"r");
	while(!feof(fp)){
		//printf("+++++++++==\n");

		fscanf(fp,"%d %d %f",&scanNode[0],&scanNode[1],&scanWt);
		if(scanNode[0]==vertex && scanNode[1]!=vertex){
			count_nbr++;
			vert[scanNode[1]]=1;
		}
		else if(scanNode[1]==vertex && scanNode[0]!=vertex){
			count_nbr++;
			vert[scanNode[0]]=1;
		}
		while((c=fgetc(fp))=='\n');
		if(c!=EOF)ungetc(c,fp);
		else break;

	}
	//printf("+==\n");
	fclose(fp);
	fp=fopen(fName,"r");
	while(!feof(fp)){
		//printf("+-------==\n");

		fscanf(fp,"%d %d %f",&scanNode[0],&scanNode[1],&scanWt);
		if(vert[scanNode[0]] && vert[scanNode[1]])count_trng++;
		while((c=fgetc(fp))=='\n');
		if(c!=EOF)ungetc(c,fp);
		else break;
	}
	//print rank coefficient
if(count_nbr!=1 && count_nbr!=0)
	printf("%d %f\n",vertex,2*count_trng/(float)(count_nbr*(count_nbr-1)));
else
printf("%d %f\n",vertex,1);
}
}

				






			
			
		
