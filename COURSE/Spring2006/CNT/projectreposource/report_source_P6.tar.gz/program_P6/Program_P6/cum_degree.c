#include<stdio.h>
#define MAX 10000

struct deg_count
{
int degree;
int count;
int sum;
};

struct deg_count arr[MAX];
int size = 0;

calculate_cum_degree()
{
int i;
int sum = 0; 
//arr[0].sum=0;
for(i=0;i<size;i++)
{
sum += arr[i].count;
arr[i].sum=sum;
//printf("%d %d\n",arr[i].degree,sum);
}
for(i=0;i<size;i++)printf("%d %f\n",arr[i].degree,arr[i].sum/MAX);

}

int main(int argc, char* argv[])
{
FILE *fp;


fp = fopen(argv[1],"r");

while(!feof(fp))
{
fscanf(fp,"%d",&arr[size].count);
fscanf(fp,"%d",&arr[size].degree);
//arr[size].sum=arr[size].count;
size++;
}

calculate_cum_degree();

}
