#include <stdio.h>

#define SIZE 10000

int main()
{
	FILE *fp,*in;
	float wtArray[SIZE]={0};
	int n1,n2,max=0,i,j;
	float temp,th;
	char str[30],c,lang[30];
	printf("file of edges\n");
	scanf("%s",str);
	printf("language\n");
	scanf("%s",lang);

	
	fp=fopen(str,"r");
	while(1){
		fscanf(fp,"%d %d %f",&n1,&n2,&temp);
		wtArray[n1]+=temp;
		wtArray[n2]+=temp;
		while((c=fgetc(fp))=='\n' ||c ==' ');
		if(c==EOF)break;
		ungetc(c,fp);
	}
	fclose(fp);
	sprintf(str,"%s_node_wt",lang);
	fp=fopen(str,"w");
	
	for(i=0;i<SIZE;i++){
		fprintf(fp,"%f\n",wtArray[i]);
		if(wtArray[i])fprintf(in,"%d\n",wtArray[i]);
	}
	fclose(fp);

}
	

	
