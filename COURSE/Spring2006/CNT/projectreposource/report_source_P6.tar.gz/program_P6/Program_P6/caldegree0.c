#include <stdio.h>

#define SIZE 200000

int main()
{
	FILE *fp,*in;
	int degArray[SIZE]={0};
	int n1,n2,max=0,i,j;
	float temp,th=0;
	char str[30],c,lang[30];
	printf("file of edges\n");
	scanf("%s",str);
	printf("language\n");
	scanf("%s",lang);

	
	fp=fopen(str,"r");

	while(1){
		fscanf(fp,"%d %d %f",&n1,&n2,&temp);
		if(temp>th){
			degArray[n1]++;
			if(max<n1)max=n1;
			degArray[n2]++;
			if(max<n2)max=n2;
		}
		while((c=fgetc(fp))=='\n' ||c ==' ');
		if(c==EOF)break;
		ungetc(c,fp);
	}
	fclose(fp);
	//printf("file of degree with vertex name\n");
	sprintf(str,"%s_degree_vert_th_eq%f",lang,th);
	fp=fopen(str,"w");
	sprintf(str,"%s_deg_th_eq%f",lang,th);
	in=fopen(str,"w");

	for(i=0;i<=max;i++){
		fprintf(fp,"%d %d\n",degArray[i],i);
		if(degArray[i])fprintf(in,"%d\n",degArray[i]);
	}
	fclose(fp);
	fclose(in);

	
}
	
