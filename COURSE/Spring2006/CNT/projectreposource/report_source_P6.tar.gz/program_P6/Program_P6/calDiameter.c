#include<stdio.h>
#include <stdlib.h>

int **ntwk,*vertices,total;
int *Q,top=0,bottom=0;

initQ(){
	top=bottom=0;
}
void enQ(int a){
	Q[top]=a;
	top++;
}

int deQ(){
	int temp;
	temp=Q[bottom];
	bottom++;
	return temp;
}

int isEmpty()
{
	if(top==bottom)return 1;
	else return 0;
}



//following diregards verteices<i
spBfs(int vert,int numV,int *sumShort,int lowInd)
{
	int sum=*sumShort;
	int i,j;
	int color[numV];
	int d[numV],pre[numV];
	int u;
	int ht=0;
	int cnt=0;
	initQ();
	for(i=lowInd;i<numV;i++)
	{
		color[i]=0;//white
		d[i]=2*numV;//infinity
		pre[i]=-1;//nil
	}
	color[vert]=1;//grey
	d[vert]=0;
	pre[vert]=-1;//nil
	enQ(vert);
	while(isEmpty()!=1)
	{
		u=deQ();//printf("%d\n",u);
		for(i=lowInd;i<numV;i++)if(ntwk[u][i]!=0){
			if(color[i]==0){
				color[i]=1;
				d[i]=d[u]+1;
				pre[i]=u;
				ht=d[i];
				enQ(i);
				if(i>vert)sum+=d[i];
			}
		}
		color[u]=2;
	}
	for(i=0;i<numV;i++){
		if(color[i]!=2){
			if((lowInd == vert) && vert==0){
				vertices[i]=0;
				total--;
			}
			else if(vertices[i]==1){
			printf("disconnected graph,vert=%d,lowInd=%d,thisVertex=%d\n",vert,lowInd,i);
				return -1;
			}
		}
	}
	*sumShort=sum;
	return ht;
}
		
	
		

	

int main(){
	FILE *fp;
	char str[30];
	int numV;
	int i,j,count=0;
	//int *pre;
	int maxShort[20];
	int sumShort[20];
	int index[20];
	int power2;
	

	printf("enter Edges File\n");
	scanf("%s",str);
	fp=fopen(str,"r");
	
	printf("enter no. of vertices to be considered\n");
	scanf("%d",&numV);
	total=numV;
	printf("enter lang\n");
	scanf("%s",str);
	sprintf(str,"%s_diameter",str);
	printf("%s\n",str);

	
	ntwk=(int **)malloc(sizeof(int *)*numV);
	Q=(int *)malloc(sizeof(int)*numV);
	vertices=(int *)malloc(sizeof(int)*numV);
	//maxShort=(int *)malloc(sizeof(int)*20);
	//sumShort=(int *)malloc(sizeof(int)*20);
	//count=(int *)malloc(sizeof(int)*20);


	if(ntwk==NULL){
		printf("error in mallocing **\n");
		return -1;
	}
	
	for(i=0;i<numV;i++){
		ntwk[i]=(int *)malloc(sizeof(int)*numV);
		if(ntwk[i]==NULL){
			printf("error in mallocing %d\n",i);
			return -1;
		}
		vertices[i]=1;
	}
	
	for(i=0;i<numV;i++){
		for(j=0;j<numV;j++)ntwk[i][i]=0;
	}
	//readNtwk();
	while(!feof(fp))
	{
		int v1,v2;
		float wt;

		fscanf(fp,"%d %d %f",&v1,&v2,&wt);
		if(v1<numV && v2<numV)ntwk[v1][v2]=ntwk[v2][v1]=1;
	}
	fclose(fp);
		
	count=-1;
	for(power2=1;power2<numV;power2*=2){
	int lowInd;
	lowInd=power2-1;	printf("power2=%d\n",power2);
	count++;
	index[count]=power2;sumShort[count]=0;maxShort[count]=0;
	for(i=lowInd;i<numV;i++){
		if(vertices[i]==0)continue;
		int temp;
		temp=spBfs(i,numV,&sumShort[count],lowInd);//returns height &updates sum of shortest pathhs
		if(temp==-1){power2=numV;break;}
		//printf("vert=%d, ht=%d , sumShort=%f\n",i,temp,avgShort);
		if(temp>maxShort[count])maxShort[count]=temp;
	}
	
	
	//fprintf(fp,"%d %d %d\n",maxShort,avgShort/numV);
	//printf("power2=%d\n",power2);

	}

	fp=fopen(str,"w");
	for(i=0;i<=count;i++)fprintf(fp,"%d %d %d %d\n",index[i],maxShort[i],sumShort[i],total-index[i]+1);



	fclose(fp);
}

	

	
	
		
		
