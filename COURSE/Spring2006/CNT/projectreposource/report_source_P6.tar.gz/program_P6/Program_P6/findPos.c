#include<stdio.h>
#include <string.h>

int main()
{
	FILE *fpwds,*fptag,*fppos;
	int i,j,t,count;
	char filename[30],tagged[30];;
	char wds[100],tocmp[100];
	printf("print file of words\n");
	scanf("%s",filename);
	fpwds=fopen(filename,"r");
	printf("print file of tagged-corpus\n");
	scanf("%s",filename);
	strcpy(tagged,filename);
	fptag=fopen(filename,"r");
	sprintf(filename,"%s_wdsPos",filename);
	fppos=fopen(filename,"w");

	i=-1;count=0;
	while(1){
		i++;if(i==2000)break;
		fscanf(fpwds,"%d %s",&t,wds);printf("%s started\n",wds);

			
		for(j=0;j<100000;j++){
			fscanf(fptag,"%[^/]",tocmp);
			while((tocmp[0]>'z' || tocmp[0]<'a') && tocmp[0]!=0)strcpy(tocmp,(tocmp+1));
			if(strcmp(tocmp,wds)==0){
				fscanf(fptag,"%s",tocmp);
				printf("%s completed\n",wds);
				fprintf(fppos,"%s %d %d\n",tocmp,i,t);
				fclose(fptag);
				fptag=fopen(tagged,"r");

				break;

			}
			else fscanf(fptag,"%s",tocmp);
		}
	}
	fclose(fppos);
}
		
		
			
	
