how to use:
1. 	Formatting the corpus : The steps are as follows

1.1 	Replace spaces & other word separates by newline.
1.2 	Sort the file using sort comand of linux.
1.3	Find frequencies using uniq command of linux.
1.4	Sort the file again numerically using sort command.
1.5	Name the output file as wordFreq.
1.6	Replace end of sentence markers in the corpus by <end> and name it as corpus1file.

2. 	Building the network : The steps are as follows 

2.1	Compile update.c & parse.c. 
2.2	Run it  on corpus1file & wordFreq to get the network as Edges file

3.	Calculate the degree of words : The steps are as follows 

3.1	Use calDegree.c to get the degrees from various Edges files. 
3.2	Sort it using the sort command and then run cum_degree.c on it to get cumulative frequencies.

4.	Calculate the cumulative coefficient :
	
4.1	Use calAllCcoeff.c to get all the clustering coefficient from Edges file.

5. 	Calculate the assortativity(mean of the degrees of the neighboring vertices) :
	
5.1	use assortative.c to get the average of degrees of adjoining nodes.

6.	findPos.c finds tags for words using a tagged corpus.

7. 	Calucalting the diameter of the network:

7.1	CalDiameter finds diameter and  avg shortest paths by removing number of nodes nodes in power of 2.

 
