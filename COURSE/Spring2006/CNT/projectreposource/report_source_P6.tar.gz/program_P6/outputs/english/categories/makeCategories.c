#include<stdio.h>
#include<string.h>

int main(int argc,char *argv[])
{
	FILE *fp,*fp1;
	
	int i,j;
	char category[10];
	char old_category[10];
	
	fp =fopen(argv[1],"r");
	if(fp == NULL)
		printf("cannot open the file\n");

	strcpy(old_category,"/CC");
	fp1 = fopen(old_category+1,"w");
	if(fp1 == NULL)
		printf("cannot open the file %s\n",old_category);
	
	while(!feof(fp))
	{
		fscanf(fp,"%s %d %d",category,&i,&j);
		if(strcmp(old_category,category) != 0)
		{	
			strcpy(old_category,category);
			fclose(fp1);
			fp1 = fopen(old_category+1,"w");
			if(fp1 == NULL)
				printf("cannot open the file %s",old_category);
		}
		else 
			fprintf(fp1,"%d %d\n",i,j);

	//	while(fgetc(c,fp) == )
	}
	fclose(fp1);
	fclose(fp);
	
}
