/*
 * SearchProtocol.java
 *
 * Created on 19 novembre 2004, 11.31
 */

package example.isearch;

import peersim.core.Linkable;
import peersim.util.CommonRandom;
import peersim.cdsim.CDProtocol;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import peersim.config.Configuration;
import peersim.core.Node;
import peersim.core.CommonState;
import example.isearch.SearchDataInitializer;

/**
 *
 * @author  giampa
 */
public abstract class SearchProtocol implements CDProtocol, Linkable {

    /** The size of the neighbor list view */
    //public static final String PAR_CACHE = "view_size";

    /** The messages TTL size */
    public static final String PAR_TTL = "ttl";

    /** Parameter for the proliferation factor. */
    public static final String PAR_PROLIFERATION = "proliferation";

    /** Parameter to choose which key comparation approach is
     * preferred. Default is OR. 
     */
    public static final String PAR_ANDMATCH = "and_keys";
    
    /** Stores each message that a node has seen. It may be cleaned by the
     *an observer considering how long a message can be valid (TTL).*/
    public HashMap messageTable;

    /** Stores each message that a node has seen. It may be cleaned by the
     *an observer considering how long a message can be valid (TTL).*/
    public HashSet hitTable;

    /** Stores the incoming received messages. The send() and forward() methods
     *can write here. Is up to the protocol behaviour processing all the queue
     *content during the cycle. */
    public ArrayList incomingQueue;

    /** The neighbor list view of the current node */
    protected ArrayList view;

    /** The local node search key storage */
    protected HashMap keyStorage;

    /** Query distribution data structure; it holds the cycle and a key array.*/
    protected TreeMap queryDistro;

    private int currentIndex; // debug
    /** Counter for thecurrent node extra probing mesages. */
    protected int extraProbeCounter;

    protected int viewSize, ttl, pid;
    protected double pFactor;
    protected boolean andMatch;
    public static int TTL;

    /** Creates a new instance of SearchProtocol */
    public SearchProtocol(String prefix, Object obj) {
        this.extraProbeCounter = 0;
        ttl = Configuration.getInt(prefix + "." + PAR_TTL, 5);
        //viewSize = Configuration.getInt(prefix + "." + PAR_CACHE, 20);
        pFactor =  Configuration.getDouble(prefix + "." + PAR_PROLIFERATION, 1.0);
        int match= peersim.config.Configuration.getInt(prefix+"."+PAR_ANDMATCH, 0);
        if (match == 1 ) this.andMatch = true;
        else this.andMatch = false;
        pid = ((Integer) obj).intValue();
        view = new ArrayList();
        messageTable = new HashMap();
        hitTable = new HashSet();
        incomingQueue = new ArrayList();
        queryDistro = new TreeMap();
        keyStorage = new HashMap();
	TTL = ttl;
    }

    public Object clone() throws CloneNotSupportedException {
        SearchProtocol sp = (SearchProtocol) super.clone();
        sp.view = new ArrayList();
        sp.keyStorage = new HashMap();
        sp.messageTable = new HashMap();
        sp.hitTable = new HashSet();
        sp.incomingQueue = new ArrayList();
        sp.queryDistro = new TreeMap();
        return sp;
    }

	public static int getttl()
	{
	return TTL;
	}

    // interface CDProtocol:
    public void nextCycle(Node node, int protocolID) {
        // currentIndex = node.getIndex();
        int currentTime = CommonState.getT();

        Iterator iter = incomingQueue.iterator();
        //while (iter.hasNext())
        int i = 0; //this is needed to flush out already used message 
	//System.out.print((node.getIndex()));
        while(i < 1)
        {
        	i = 1;
        if(iter.hasNext())	
        {
            SMessage mes = (SMessage) iter.next();
 //           if (mes.hops == (currentTime - mes.start + 1))
 //               continue;
		//System.out.print(",  " + (currentTime - mes.start) + ",  " + ttl  + ",  " );
            if(currentTime - mes.start >= ttl)
            		{
            		i = 0;
            		iter.remove();
			//System.err.println("Removing old");
            		continue;
            		}
            this.process(mes);
            Integer actual = (Integer) this.messageTable.get(mes);
            int index = (actual != null ? actual.intValue() + 1 : 1);
            this.messageTable.put(mes, new Integer(index));
            //this.process(mes);
            iter.remove();
        }
        }
    }

    /** Send a message to a Node. Used by the query originator. It takes care to
     *increase the message TTL.
     *
     *@param n The node to communicate with.
     *@param mes The message to be fsent.
     */
    public void send(Node n, SMessage mes) {
        try {
            SMessage copy = (SMessage) mes.clone();
            copy.hops++;
		/******added by niloy*********/
            Integer actual = (Integer) this.messageTable.get(mes);
            int index = (actual != null ? actual.intValue() + 1 : 1);
            this.messageTable.put(mes, new Integer(index));
            SearchProtocol sp = (SearchProtocol) n.getProtocol(pid);
            //System.err.println(
            //    "send: " + currentIndex + " -> " + n.getIndex() + ": " + copy);
            sp.incomingQueue.add(copy);
	  // System.out.println("Is it growing" + sp.incomingQueue.size());
        } catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
        }
    }

    /** Forwards a message to a node. Used by the nodes along the message
     *path. It takes care to increase the message TTL and stops forwarding if it
     *is too high.
     *
     *@param n The node to communicate with.
     *@param mes The message to be forwarded.
     */
    public void forward(Node n, SMessage mes) {
        //NOTE: it does not insert the message in the neighbor messageTable
        //because I belive that this operation has to performed by the
        //neighbor itselt; the idea is that a node has "to see" by itself.
        //if (mes.hops < ttl) {
            try {
                //clone message and update TTL:
                SMessage copy = (SMessage) mes.clone();
                copy.hops++;
                SearchProtocol sp = (SearchProtocol) n.getProtocol(pid);
                copy.type = SMessage.FWD; // sets FWD type
                //                System.err.println(
                //                    "forward: "
                //                        + currentIndex
                //                        + " -> "
                //                        + n.getIndex()
                //                        + ": "
                //                        + copy);
                sp.incomingQueue.add(copy);
            } catch (CloneNotSupportedException cnse) {
                System.out.println("Troubles with message cloning...!");
         //   }
        }
    }

    /** Select a free node from the current view. It is used by the restricted
     *protocol versions. It always return a random node even if no free node are
     *available.
     *
     *@param The message the nodes must be "free".
     */
    public Node selectFreeNeighbor(SMessage mes) {
        Collections.shuffle(this.view, CommonRandom.r); // same as random pick
        Node result = null;

        for (int i = 0; i < this.view.size(); i++) {
            this.extraProbeCounter++;
            Node n = (Node) this.view.get(i);
            SearchProtocol sp = (SearchProtocol) n.getProtocol(pid);
            if (!sp.messageTable.containsKey(mes)) {
                result = n;
                break;
            }
        }

        if (result == null) {
            result = (Node) this.view.get(0);
        }
        return result;
    }

    /** It is the equivalent of the passive thread in real setup. It has to
     *manage incoming message requests that are available in the incomingQueue
     *data structure.
     *BTW this method has to deal with only a single message at a time and the
     *basic nextCycle method of CDProtocol will provide the available messages.
     *
     *@param mes The message to process. 
     */
    public abstract void process(SMessage mes);

    /** Notify a hit in the current node messageTable. The absolute value
     *indicates how many times the message has been seen and the negative sign
     *indicates a succesful query hit.
     *
     *@param mes The message for which it notifies a hit.
     */
    public void notifyOriginator(SMessage mes) {
        this.hitTable.add(mes);
    }


    /** Performs the actual checks to compare query keys to the protocol own
     *key storage. The returning array may be NULL elements.
     *
     *@param keys The array of keys to be checked, it is extracted from the
     *message.
     *@return A new array of keys: the ones that has matched. It may be null if
     *no keys has matched.

    protected int[] matches(int[] keys) {
        int[] result = null;
        ArrayList temp = new ArrayList();
        for (int i = 0; i < keys.length; i++) {
            if (this.keyStorage.containsKey(new Integer(keys[i]))) {
                temp.add(new Integer(keys[i]));
            }
        }
        if (temp.size() > 0) {
            result = new int[temp.size()];
            for (int i = 0; i < temp.size(); i++) {
                result[i] = ((Integer) temp.get(i)).intValue();
            }
        }
        return result; //  check: not so sure!!
    }
     */


    /** Performs the actual checks to compare query keys to the protocol own
     *key storage. It returns if a hit has happended according to the
     *actual comparison method (AND or OR).
     *
     *@param keys The array of keys to be checked, it is extracted from the
     *message.
     *@return If a hit has occurred.
    protected boolean match(int[] keys) {
        boolean result = false;
	//long hallo;
//	System.out.println(SearchDataInitializer.keywordswidth());
        int[] matchedKeys = this.matches(keys);
        if (matchedKeys != null ) {
            // and match
            if (andMatch && matchedKeys.length == keys.length)
                result = true;
            else if (!andMatch) 
                result = true;
        }
        return result;
    }
     */

public int SelectNoNeighbor(int HD, int neighbor)
{
int NoNeighbour = 1; /****** At least one *********/
int k;
                k =(int) Math.ceil(Math.exp((double)HD) * ((double)neighbor/4.0));
        for(int i = 1; i < neighbor; i++)
                {
                if(CommonRandom.r.nextInt(k) == 0)
                         NoNeighbour++;
                }

return NoNeighbour;

}

/*This function converts a decimal number to a binary string*/
public int [] convert_to_binary(int no)
{
int WdSize = (int)SearchDataInitializer.keywordswidth();

int [] a = new int[WdSize];
int i = 0;
while(no > 0)
        {
        a[i]= no%2;
        no  = no/2;
        i++;
        }
return a;
}

/*This function checks the hamming distance between two binary arrays*/
public int checkdifference(int[] aArray, int[] bArray)
{
int  WdSize = (int)SearchDataInitializer.keywordswidth();
int diff=0;
for(int i=0; i<WdSize; i++)
        if(aArray[i] != bArray[i])
                diff++;
return diff;
}
protected int[] matches(int[] keys) 
{
int [] result = new int[1]; // this is hard coded
Iterator iter = this.keyStorage.keySet().iterator();
int i=0;
while (iter.hasNext())
	{
		Integer ikey = (Integer) iter.next();
		result[i] = ikey.intValue();
		//System.out.println((Integer)this.keyStorage.get(ikey));
		//System.out.println(result[i]);
		i ++;
	}
	return result;
}
    
    protected int match(int[] keys) {
	
        int[] matchedKeys = this.matches(keys);
	//assuming there is one single number
	int[] binarykey = convert_to_binary(keys[0]); 
	int[] binarymatchedkey = convert_to_binary(matchedKeys[0]); 
	int diff = checkdifference(binarykey,binarymatchedkey);
	return diff;

	}
    
    /** Picks the current node query data distribution to send a message from
     *the local node distribution structure.
     *
     *@return The set of keys in the query according to the distribution.
     */
    protected int[] pickQueryData() {
        int[] result = null;

        if (queryDistro.isEmpty())
            return null;

        Integer key = (Integer) queryDistro.firstKey();
        //new Integer(CommonState.getT());
        if (key.intValue() == CommonState.getT()) {
            result = (int[]) queryDistro.get(key);
            queryDistro.remove(key);
        }

        return result;
    }

    /** Load the current node query data distribution structure.
     *
     *@param cycle The cycle in which perform the query.
     *@param keys The query set.
     */
    public void addQueryData(int cycle, int[] keys) {
        //        System.err.print("adding query: ");
        //        for (int i = 0; i < keys.length; ++i)
        //            System.err.print(keys[i] + " ");
        //        System.err.println(" scheduled @" + cycle);

        this.queryDistro.put(new Integer(cycle), (Object) keys);
    }
    
    /** Sets the node specific keys collection and their own frequency. Should
     *be called by the initializer.
     *
     *@param entry A mapping from a key to its frequency.
     */
    public void addKeyStorage(Map entry) {
        this.keyStorage.putAll(entry);
    }
    
    // Linkable interface implementation:
    public boolean addNeighbor(peersim.core.Node neighbour) {
        view.add(neighbour);
        return true;
    }

    public boolean contains(peersim.core.Node neighbor) {
        return this.view.contains(neighbor);
    }

    public int degree() {
        return this.view.size();
    }

    public peersim.core.Node getNeighbor(int i) {
        return (peersim.core.Node) this.view.get(i);
    }

    public void pack() {
        ;
    }

}
