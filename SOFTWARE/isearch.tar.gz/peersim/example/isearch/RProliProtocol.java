/*
 * RProliProtocol.java
 *
 * Created on 19 novembre 2004, 18.23
 */

package example.isearch;

import peersim.core.Node;
import java.util.Collections;


/**
 *
 * @author  giampa
 */
public class RProliProtocol extends RWProtocol {
    
    /** Creates a new instance of RProliProtocol */
    public RProliProtocol(String prefix, Object obj)  {
        super(prefix, obj);
    }
    
    public void process(SMessage mes) {
        // checks for hits and notifies originator if any:
        //boolean match = this.match(mes.payload);
        int match = this.match(mes.payload);
        if (match == 0) this.notifyOriginator(mes);
	

	int k = 1;
	if(!this.messageTable.containsKey(mes))
		k = this.SelectNoNeighbor(match,this.view.size());
	//System.out.print("K " + k);
        
	Collections.shuffle(this.view, CommonRandom.r);
	if (k > this.view.size())
		System.err.println("PLEASE CHECK THE PROLIFERATION FUNCTION" + k);
	/***The others***/
	int check = 0;
	for (int i = 0, j = 0 ; i < k; i++, j++) {
		if (j  >= this.view.size()) 
			break;
            this.extraProbeCounter++;
            Node n = (Node) this.view.get(i);
            SearchProtocol sp = (SearchProtocol) n.getProtocol(pid);
            if (sp.messageTable.containsKey(mes)) {
               	continue; 
            }

	check ++;
	// forwards the message to a random neighbor:
	//System.out.print("IN " + actual.intValue());
	if( check > 0)
	{
		Integer actual = (Integer) this.messageTable.get(mes);
		int index = (actual != null ? actual.intValue() + 1 : 1);
	//System.out.println("There is problem" + index);
	this.messageTable.put(mes, new Integer(index));
	}
        Node neighbor = (Node) this.view.get(i);
        this.forward(neighbor, mes);
	}
	if(check == 0)
	{
		Node neighbor = (Node) this.view.get(0);
	        this.forward(neighbor, mes);

	}
	//System.out.println(" ");

    }
}
