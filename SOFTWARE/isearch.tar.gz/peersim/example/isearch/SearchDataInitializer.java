/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package example.isearch;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.*;

import peersim.cdsim.Simulator;
import peersim.config.*;
import peersim.core.*;
import peersim.dynamics.Dynamics;
//import example.isearch.zipfSimple;
//import peersim.util.CommonRandom;

public class SearchDataInitializer implements Dynamics {

    ////////////////////////////////////////////////////////////////////////////
    // Constants
    ////////////////////////////////////////////////////////////////////////////

    /** 
     * String name of the parameter used to determine the width of the distinct
     * keywords.
     */
    public static final String PAR_KEYWORDS_WIDTH = "keywordsWidth";

    /** 
     * String name of the parameter used to determine the number of
     * nodes emitting queries (default = network size)
    public static final String PAR_QUERY_NODES = "query_nodes";
     */

    /** 
     * String name of the parameter used to determine the maximum number of queries
     * emitted by a single node (default = unlimited).
     * 
     */
    public static final String PAR_MAX_QUERIES = "max_queries";
	/**
	* Simulateneously, how many search will go together, default = 1
	*/

    public static final String PAR_SIM_SEARCH = "simultSearch";

    /** 
     * zipf's exponent for data and query distribution
     * between queries for the Poisson distribution (default = 10).
     */
    public static final String PAR_ZIPF_DATA = "data_zipf";
    public static final String PAR_ZIPF_QUERY = "query_zipf";

    /** 
     * String name of the parameter that defines the protocol to initialize.
     * Parameter read will has the full name
     * <tt>prefix+"."+PAR_PROT</tt>
     */
    public static final String PAR_PROT = "protocol";

    /** 
     * Distribution used to generate the required random numbers.
     */
    private final long keywordsWidth;

   // private final int query_nodes;

    private final int max_queries;

    //private final int query_interval;

    private final int protocolID;

    private final int simultSearch;

    private final double data_zipf;

    private final double query_zipf;

    private final long maxCycles;

    private final long TestmaxCycles = 5;

    public static long PublicKeyWidth;

    public static int MAXquery;

    ////////////////////////////////////////////////////////////////////////////
    // Initialization
    ////////////////////////////////////////////////////////////////////////////

    public SearchDataInitializer(String prefix) {
        keywordsWidth = Configuration.getLong(prefix + "." + PAR_KEYWORDS_WIDTH);
        protocolID = Configuration.getPid(prefix + "." + PAR_PROT);
        //query_nodes = Configuration.getInt( prefix + "." + PAR_QUERY_NODES, Network.size());
        max_queries = Configuration.getInt(prefix + "." + PAR_MAX_QUERIES, 0);
        data_zipf = Configuration.getDouble(prefix + "." + PAR_ZIPF_DATA, 1.0);
        query_zipf = Configuration.getDouble(prefix + "." + PAR_ZIPF_QUERY, 1.0);
        simultSearch = Configuration.getInt(prefix + "." + PAR_SIM_SEARCH, 1);
        //max_queries = Configuration.getInt(prefix + "." + PAR_MAX_QUERIES, 0);
        //query_interval = Configuration.getInt(prefix + "." + PAR_QUERY_INTERVAL, 10);
        maxCycles = Configuration.getInt(Simulator.PAR_CYCLES);
	PublicKeyWidth = keywordsWidth;
	MAXquery = max_queries;
    }

    ////////////////////////////////////////////////////////////////////////////
    // Methods
    ////////////////////////////////////////////////////////////////////////////


    // Comment inherited from interface
    public void modify() {
        int[][]  DataQuery = zipfSimple.form_keyword_array(keywordsWidth,data_zipf,query_zipf, max_queries);
	/*for(int i = 0; i < (int)Math.pow(2,keywordsWidth); i++)
        {
        System.out.print( " " + DataQuery[0][i] +"," + DataQuery[1][i] + "," + DataQuery[2][i] );
        }
	System.out.println("");
        System.out.println("");*/


	int[][] nodeData = zipfSimple.placeinNode(DataQuery,max_queries);

        for (int i = 0; i < Network.size(); ++i) {
            SearchProtocol proto =
                //((SearchProtocol) Network.get(nodeData[0][i]).getProtocol(protocolID));
                ((SearchProtocol) Network.get(i).getProtocol(protocolID));
        	   initializeData(proto,nodeData[1][nodeData[0][i]]);
                initializeQueries(proto,nodeData,i);
            
        }
    }

	/*******Lets try to take keywordswidth out******/
public  static long keywordswidth()
{
return PublicKeyWidth;
}

public  static int maxquery()
{
return MAXquery;
}
    /**
     * Fills a {@link SearchProtocol} with the keywords representing the documents
     * it holds.
     * @param proto the protocol to initialize
     */
    private void initializeData(SearchProtocol proto, int key) {
        // create the stored keywords
        // number of keywords held by the node (poisson)
        //int storageSize = CommonRandom.r.nextPoisson(1 + keywords / 1000);
        int storageSize = 1;
        Map keyStorage = makeKeyMap(storageSize,key);
        //printContents(keyStorage);
        proto.addKeyStorage(keyStorage);
     
    }
    /**
     * Fills a {@link SearchProtocol} with the queries it will initiate.
     * @param proto the protocol to initialize
*/
    private void initializeQueries(SearchProtocol proto, int [][] nodeData, int which) {
	for(int i = 0; i < nodeData[2][which]; i+= 2)
	{
	    int querySize = 1;
	    int cycle = (nodeData[i+4][which]/simultSearch)*proto.ttl;
            int[] query = makeKeyArray(querySize,nodeData[i+3][which]);
	    /*for(int j = 0; j < 1; j++)
		System.out.println("(" + cycle + " " + query[j] + " " + ")");*/
            proto.addQueryData(cycle,query);
        }
    }

    private Map makeKeyMap(int size,int key) {
        HashMap keys = new HashMap();
        while (keys.size() < size) {
            /*int key =
                (int) Math.ceil(CommonRandom.r.nextPower(keywords / 100, 1.0));
            if (key > keywords)
                continue;*/
            Integer ikey = new Integer(key);
            Integer oldValue = (Integer) keys.get(ikey);
            int newval = (oldValue == null ? 1 : oldValue.intValue() + 1);
            keys.put(ikey, new Integer(newval));
        }

        return keys;
    }

    private int[] makeKeyArray(int size, int key) {

        int[] result = new int[size];
        for (int i = 0; i < size; ++i) {
            result[i] = key;
        }
        return result;
    }

    private static void printContents(Object o){
    	 
    	         //If its a Map, then we need to get its collection
    	         if (o instanceof java.util.Map) {
    	           o = ((java.util.Map)o).entrySet();
    	         }
    	 
    	         // Now we can loop through and print contents of the collection
    	         if (o instanceof java.util.Collection) {
    	           java.util.Collection c = (java.util.Collection)o;
    	           java.util.Iterator myIter = c.iterator();
    	           while (myIter.hasNext()) {
    	           System.out.println(myIter.next());
    	         }
    	     } 
    	      // System.out.println();
    	     }
}
