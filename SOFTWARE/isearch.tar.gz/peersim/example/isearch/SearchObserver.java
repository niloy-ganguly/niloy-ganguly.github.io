/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package example.isearch;

import java.util.HashMap;
import java.util.Iterator;

import peersim.core.*;
import peersim.reports.*;
import peersim.config.*;

public class SearchObserver implements Observer {
    // Constant fields:
    /**
     *  String name of the parameter used to select the protocol to operate on
     */
    public static final String PAR_PROT = "protocol";

    /**
     * String name of the parameter used to set the verbosity level.
     * The default is 0 (non verbose).
     */
    public static final String PAR_VERBOSITY = "verbosity";

    // Fields:
    /** The name of this observer in the configuration */
    private final String name;

    /** Protocol identifier */
    private final int pid;

    private final int verbosity;

    private final int len = Network.size();

    public static int MessageNo;

    // Constructor:
    public SearchObserver(String name) {
        // Call the parent class (abstract class)
        this.name = name;
        // Other parameters from config file:
        pid = Configuration.getPid(name + "." + PAR_PROT);
        verbosity = Configuration.getInt(name + "." + PAR_VERBOSITY, 0);
    }

    // Implementation of the Observer Interface:

    public boolean analyze() {
        HashMap messageStats = new HashMap();
        int time = peersim.core.CommonState.getT();

        for (int i = 0; i < len; i++) {
            SearchProtocol prot =
                (SearchProtocol) Network.get(i).getProtocol(pid);
	    //if(prot.incomingQueue.size()!=0)
	    //{
	    //System.out.println("xxx" + prot.incomingQueue.size());
	    //}
	    MessageNo  += prot.incomingQueue.size();
            int ttl = prot.ttl;
            Iterator iter = prot.messageTable.keySet().iterator();
            while (iter.hasNext()) {
                SMessage msg = (SMessage) iter.next();
                int age = time - msg.start - 1;
                //if (age > ttl) continue;
                Integer msgValue = (Integer) prot.messageTable.get(msg);
                //int msgs = msgValue.intValue();
		//This make the total program single based
                int msgs = prot.incomingQueue.size();
                int hits = (prot.hitTable.contains(msg) ? 1 : 0);
                SearchStats stats = (SearchStats) messageStats.get(msg);
                if (stats == null) {
                    stats = new SearchStats(msg.seq, age, ttl);
                    messageStats.put(msg, stats);
                }
                stats.update(msgs, hits);
                if (age >= ttl - 1) {
                    iter.remove();
                    prot.hitTable.remove(msg);
                }
            }
        }

        Iterator iterStats = messageStats.values().iterator();
        while (iterStats.hasNext()) {
            SearchStats stats = (SearchStats) iterStats.next();
            if (verbosity == 0 && stats.age < stats.ttl - 1) continue;
            System.out.println(stats + " " + MessageNo);
	   if(stats.age ==  stats.ttl - 1)
		MessageNo = 0;
        }

        return false;
    }

    // End of interface implementation
    //*******************************

    class SearchStats {
        /** Number of nodes having see the query */
        private int nbSeen;

        /** Number of hits */
        private int nbHits;

        /** Number of messages sent on behalf of this query */
        private int nbMessages;

        /** Number of extra probes sent on behalf of this query */
        private int nbExtraProbes;
        
        /** Sequence number of the message */
        private int seq;

        /** Age of this query */
        private int age;

        /** Time to live of this query */
        private int ttl;
        
        public SearchStats(int seq, int age, int ttl) {
            this.nbSeen = 0;
            this.nbHits = 0;
            this.nbMessages = 0;
            this.nbExtraProbes = 0;
            this.seq = seq;
            this.age = age;
            this.ttl = ttl;
        }

        public void update(int msgs, int hits) {
            ++nbSeen;
            nbHits += hits;
            nbMessages += msgs;
        }

        public String toString() {
            //return ("" + seq + " " + age + " " + nbSeen + " " + nbHits + " " + nbMessages);
            return ("" + seq + " " + age + " " + nbSeen + " " + nbHits);
        }
    }
}
