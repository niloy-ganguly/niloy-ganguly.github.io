/*
 * RRWProtocol.java
 *
 * Created on 19 novembre 2004, 18.23
 */

package example.isearch;

import peersim.core.Node;

/**
 *
 * @author  giampa
 */
public class RRWProtocol extends RWProtocol {
    
    /** Creates a new instance of RRWProtocol */
    public RRWProtocol(String prefix, Object obj)  {
        super(prefix, obj);
    }
    
    public void process(SMessage mes) {
        // checks for hits and notifies originator if any:
        //boolean match = this.match(mes.payload);
        int match = this.match(mes.payload);
        if (match == 0) this.notifyOriginator(mes);
        
        // forwards the message to a random FREE neighbor:
        Node neighbor = this.selectFreeNeighbor(mes);
        this.forward(neighbor, mes);
    }
}
