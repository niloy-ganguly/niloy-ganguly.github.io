/*
 * RWProtocol.java
 *
 * Created on 19 novembre 2004, 16.29
 */

package example.isearch;

//import peersim.cdsim.CDProtocol;
import peersim.util.CommonRandom;
import peersim.config.Configuration;
import peersim.core.Node;
import peersim.core.*;

/**
 *
 * @author  giampa
 */
public class RWProtocol extends SearchProtocol {
    
    /** Parameter for the number of walkers at the query 
     *initiation. It must be < then view size.  Default is 1.
     */
    public static final String PAR_WALKERS = "walkers";
    
    protected int walkers;
    
    /** Creates a new instance of RWProtocol */
    public RWProtocol(String prefix, Object obj) {
        super(prefix, obj);
        walkers = Configuration.getInt(prefix+"."+PAR_WALKERS, 1);
    }

    // "Passive" behaviour implementation: process key similarity and notifies
    // any  match and forwards messages.
    public void process(SMessage mes) {
        // checks for hits and notifies originator if any:
        /*boolean match = this.match(mes.payload);
        if (match) this.notifyOriginator(mes);*/
        int match = this.match(mes.payload);
        if (match == 0) this.notifyOriginator(mes);
        
	// forwards the message to a random neighbor:
        Node neighbor =
            (Node) this.view.get(CommonRandom.r.nextInt(view.size()));
	//System.out.print("goes to " + (neighbor.getIndex()));
        this.forward(neighbor, mes);
    }

    // "active" behaviour implementation: makes query
    public void nextCycle(peersim.core.Node node, int protocolID) {
        super.nextCycle(node, protocolID);
        // this will handle incoming messages
	//System.out.println(" ");
        int[] data = this.pickQueryData(); // if we have to produce a query...
        if (data != null) {
            SMessage m = new SMessage(node, SMessage.QRY, 0, data);
            //System.err.println("sending to " + view.size() + " neighbours: " + m);
            // produces the specified number of walkers:
            //for (int i = 0; i < this.walkers && i < this.view.size(); i++) {
            for (int i = 0,j = 0; i < this.walkers; i++,j++) {
            	if(j ==this.view.size())
            		j=0;
                //this.send((Node) this.view.get(j), m);
                this.send(node,m);
            }
        }
    }

}
