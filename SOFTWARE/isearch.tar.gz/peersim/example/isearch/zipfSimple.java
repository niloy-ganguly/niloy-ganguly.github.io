/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package example.isearch;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Collections;

import peersim.cdsim.Simulator;
import peersim.config.*;
import peersim.core.*;
import peersim.dynamics.Dynamics;
import example.isearch.SearchDataInitializer;
//import peersim.util.CommonRandom;

public class zipfSimple {

    ////////////////////////////////////////////////////////////////////////////
    // Constants
    ////////////////////////////////////////////////////////////////////////////


   private static int max_queries;

   private static long maxCycles;

private static int len;

private static long total_words;


public static double total_in_zipfs_law(double fraction)
{
int i;
float total=0;
for ( i = 1; i<= len; i++)
        {
        total += (1/Math.pow((float)i,fraction));
        }
return(total);
}

public static void form_array(int [] Array, double fraction)
{
double TotalFrac = total_in_zipfs_law(fraction);
double spillover = 0;
int cum_words =0;

for(int i=0; i<len; i++)
        {
                double temp = Math.pow((i+1),fraction);
                double totOccur = total_words/(TotalFrac * temp) + spillover;
                spillover = totOccur - (int)totOccur;
		Array[i] = (int)totOccur;
		cum_words += (int)totOccur;
        }
if(cum_words != total_words)
	{
		Array[len-1] += total_words-cum_words;
		//System.out.println("this line comes rarely");
	}
}


public static void shuffle(int [] Array, int Len) 
{

        for(int i = Len; i>1; i--)
	{
	int j = CommonRandom.r.nextInt(i);
	int k = i-1;
	int n = Array[k];
        Array[k] = Array[j];
        Array[j] = n;

	}
}


public static int[][] form_keyword_array(long keyWidth, double data_zipf, double query_zipf, int maxQuery)
{

	len = (int)Math.pow(2,keyWidth);
	int [][] Array = new int [3][len];
	for(int i = 0; i < len; i++)
			Array[0][i] = i;
	shuffle(Array[0],len);
	
	/**For Data**/
	
	total_words = Network.size();
	form_array(Array[1],data_zipf);
	
	/**For Query**/
	total_words = maxQuery;
	form_array(Array[2],query_zipf);
	
return(Array);
}


public static int[][] placeinNode(int [][] DataQuery, int max_queries)
{
	len = Network.size();
	maxCycles = Configuration.getInt(Simulator.PAR_CYCLES);

	int kLen = 3 + 4 * (int)Math.ceil((double)((double)max_queries/(double)len));
	//System.out.println("K =  " + kLen);
	int [][] DataArray = new int [kLen][len];

	for(int i = 0; i < len; i++)
		DataArray[0][i] = i;
	shuffle(DataArray[0],len);

	int j = 0;
	for(int i = 0; i < len; i++)
		{
		while(DataQuery[1][j] == 0)
			j++;
		DataArray[1][i] = DataQuery[0][j];
		DataQuery[1][j] --;
		}

	/**This shuffling is to keep query cycles of similar query far apart*/
	int [] Query = new int[max_queries];
	for(int i = 0; i < max_queries; i++)
		Query[i] = i;
	shuffle(Query,max_queries);


	j = 0;
	for(int i = 0; i < max_queries; i++)
		{
		int k = CommonRandom.r.nextInt(len);
		int p = DataArray[2][k] + 3;
		while(DataQuery[2][j] == 0)
			j++;
		if(p < kLen - 1)
			{
			DataArray[p][k] = DataQuery[0][j];
			DataArray[p+1][k] = Query[i];
			DataArray[2][k] += 2;
			DataQuery[2][j] --;
			}
		}

/*	for(int i = 0; i < len; i++)
		{
		System.out.print( " [");
		for(int p = 0; p < DataArray[2][i] + 3; p++)
			{
			System.out.print( " " + DataArray[p][i]);
			}
		System.out.print( " ]");
		System.out.println(" ");
		}*/
	return(DataArray);

}

}
