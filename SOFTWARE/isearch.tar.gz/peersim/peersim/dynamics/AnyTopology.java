/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
		
package peersim.dynamics;

import peersim.graph.*;
import peersim.core.*;
import peersim.config.Configuration;
import peersim.util.CommonRandom;

import java.io.*; //change

/**
* Takes a {@link Linkable} protocol and adds random connections. Note that no
* connections are removed, they are only added. So it can be used in
* combination with other initializers.
*/
public class AnyTopology implements Dynamics { //, NodeInitializer {


// ========================= fields =================================
// ==================================================================


/** 
*  String name of the parameter used to select the protocol to operate on
*/
public static final String PAR_PROT = "protocol";

/** 
*  String name of the parameter to set the out-degree degree of the graph.
*/
//public static final String PAR_DEGREE = "degree";

/** 
*  String name of the parameter to set if the graph should be undirected,
* that is, for each link (i,j) a link (j,i) will also be added.
*/
public static final String PAR_UNDIR = "undirected";

/**
     *  String name of the parameter used to name topology specification file.
     */
    public static final String PAR_FILENAME = "filename";

/**
* The protocol we want to wire
*/
private final int protocolID;

/**
* The degree of the regular graph
*/
//private final int degree;

private final boolean undirected;

private final String filename;// changes


// ==================== initialization ==============================
//===================================================================


public AnyTopology(String prefix) {

	protocolID = Configuration.getPid(prefix+"."+PAR_PROT);
//	degree = Configuration.getInt(prefix+"."+PAR_DEGREE);
	undirected = Configuration.contains(prefix+"."+PAR_UNDIR);
	filename = Configuration.getString(prefix+"."+PAR_FILENAME);
}


// ===================== public methods ==============================
// ===================================================================


/** calls {@link GraphFactory#wireRegularRandom}.*/
public void modify() {
BufferedReader br; //changes
        try {
            br = new BufferedReader(new FileReader(filename));
        }
	catch (FileNotFoundException e) {
	    System.out.println("Error (TopologyInitializer): unable to open file '" + filename + "' for reading.");
	    return;
	}
	Graph g = new OverlayGraph(protocolID,undirected);

        String line;
        while (true) {
            try {
                line = br.readLine();
            }
            catch (IOException e) {
                System.out.println("Error (TopologyInitializer): while reading topology data.");
                break;
            }
            if (line == null) { // EOF
                break;
            }

            try {
                int node =
                    Integer.valueOf(line.substring(0, line.indexOf(" "))).intValue();
                int linkTo =
                    Integer.valueOf(line.substring(line.indexOf(" ")+1)).intValue();
//                System.out.println("Link = " + linkTo);
            	g.setEdge(node,linkTo);

            }
            catch (NumberFormatException e) {
                System.out.println("Error (TopologyIntializer): unable to parse topology data.");
            }
        }

        try {
            br.close();
        }
        catch (IOException e) {
            System.out.println("Error (TopologyInitializer): while closing topology file.");
        }

        //for(int j=0; j<9; ++j)
        	//System.out.println(j + " " + g.getNeighbours(j));
	
	/*GraphFactory.wireRegularRandom(
		new OverlayGraph(protocolID,!undirected), 
		degree,
		CommonRandom.r );*/
}

// -------------------------------------------------------------------

/**
* Takes {@link #PAR_DEGREE} random samples with replacement
* from the node of the overlay network.
*/
/*public void initialize(Node n) {

	if( Network.size() == 0 ) return;
	
	for(int j=0; j<degree; ++j)
	{
		((Linkable)n.getProtocol(protocolID)).addNeighbor(
		    Network.get(
			CommonRandom.r.nextInt(Network.size())));
	}
}*/

}

