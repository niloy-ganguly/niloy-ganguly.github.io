
poisson(int mean,int *endCount,int *PoissonTable)
{
int i = 0;
int Count = 0;
double f;
int sum = 0,firstCount;
int tag = 0;
f = exp(-mean) * pow(mean,i);
if (f * 1000000 >= 1 )
        {
        if(tag == 0)
        {
        tag = 1;
        firstCount = i;
        }
	sum = sum + f*1000000;
	PoissonTable[Count++]= sum;
	tag = 1;
	firstCount = 0;
	}

//printf("%f ",f);

for(i = 1; ; i++)
{
if(f == 0)
	{
	if(pow((float)mean/(float)i,i) < DBL_MAX)
		f = exp(-mean + i) * pow((float)mean/(float)i,i)/ sqrt(2.0 *pi *i);
	else 
		f = 0;
	}
else
	f *= (float)(mean)/(float)(i);
if (f * 1000000 >= 1 )
	{
	if(tag == 0)
	{
	tag = 1;
	firstCount = i;
	}
	sum = sum + f*1000000;
	PoissonTable[Count++]= sum;
	//printf("%d ",sum);
	
	}
else
	if (tag == 1)
		{
		*endCount = i;
		break;
		}
}
return(firstCount);
}

int ReturnRandom(int *PoissonTable, int length, int StartC)
{
int i,j,k;
k = rand()%1000000;
for(j = 0; j < length; j ++)
	if(k < PoissonTable[j])
		return(StartC + j);
return(StartC + length);
}

randomPoisson(int mean, int n, int *PoissonContainer)
{
int i,j,k;
time_t t;
int *PoissonTable,StartC,EndC;
int LENGTH = 4 * mean;
k=(unsigned)time(&t);
srand(k);
if (LENGTH < 50)
	LENGTH = 50; 
PoissonTable = (int *)calloc(LENGTH,sizeof(int));
StartC = poisson(mean,&EndC,PoissonTable);

for(i = 0; i< n; i++)
	PoissonContainer[i] = ReturnRandom(PoissonTable,EndC-StartC,StartC);

free(PoissonTable);

}




int FormPartition(int meanLength, int *Tot,int **parti, int **imporTance,int *TempSelection,
int *Tot_1)
{
int i=0,j,k,No,tag,Temp,I;
int TotSymbol = *Tot;
int TotWords = *Tot_1;
for(;;)
{
No = random_generation()%TotWords;
No = TempSelection[No];
Temp = TempSelection[TotWords -1];
TempSelection[TotWords -1] = TempSelection[No];
TempSelection[No] = Temp;
k = random_generation()%meanLength;
if(k == 0)
	continue;
No = imporTance[2][No]; /********+Pointing to the right position***/
if( No == -1)
	continue;
      tag=0;
      for(j = 0; j < i; j++)
      if(imporTance[0][No] == parti[0][j])
      { 
	tag = 1;
        break;
      }
  //    if (tag == 0)
      {        
	if(imporTance[1][No] == 0) /******** No element ********/
	 {
		imporTance[2][imporTance[0][No]]= -1;
		if(No != TotSymbol - 1)
		{
		imporTance[0][No] = imporTance[0][TotSymbol - 1]; 
		imporTance[1][No] = imporTance[1][TotSymbol - 1]; 
		imporTance[2][imporTance[0][No]]=No;
		}
		TotSymbol--;
		continue;
	 }	
	else
	 {
		if(imporTance[1][No] <= k) /********less or equal to requested ******/
	 	{
		parti[0][j] = imporTance[0][No];
		parti[1][j] += imporTance[1][No];
		k = imporTance[1][No];
		imporTance[2][imporTance[0][No]]= -1;
		if(No != TotSymbol - 1)
		{
		imporTance[0][No] = imporTance[0][TotSymbol - 1];
                imporTance[1][No] = imporTance[1][TotSymbol - 1];
		imporTance[2][imporTance[0][No]]=No;
		}
                TotSymbol--;
		}
		else
		{
		parti[0][j] = imporTance[0][No];
		parti[1][j] += k;
		imporTance[1][No] -= k;
		}
         TotWords--;
		
	}
		
if(tag == 0)
        i++;
	
      }
meanLength = meanLength - k;
//printf("(%d,%d) ",j,k);
if(meanLength == 1)
	break;
}
*Tot = TotSymbol;
*Tot_1 = TotWords;
return(i);
}

/**********The routine specifies the number of elements that should occur *******/
ArrangeOccurrence(int number,int **imporTance,float fraction,int total_words)
{
float TotalFrac,temp,totOccur,spillover;
int i,j;

TotalFrac = total_in_zipfs_law(number,fraction);
for(i= number - 1,j=0 ;i >= 0; j++,i--)
        {
                temp = pow((j+1),fraction);
		totOccur = total_words/(TotalFrac * temp) + spillover;
            	imporTance[1][i] = (int)totOccur;
                spillover = totOccur - (int)totOccur;
            	imporTance[2][imporTance[0][i]] = i;
	}

}

/****Fills with the frequency of the queries**********/
ModelQueries(int number, int **imporTance, int total_words,int *TempSelection)
{
int i,j,I;
//srand(0);
for(i=0;i<number; i++)
        {
                for(j = 0; j < imporTance[1][i];)
                        {
                        I = rand()% total_words;
                        if(TempSelection[I] == 0)
                                {
                                j++;
                                TempSelection[I] = imporTance[0][i];
                                }
                        }
        }
}

GenerateInformationProfile(int *TempSelection,int number,int words, int total_nodes,PROFILE *Computer)
{
int i;
int *PoissonContainer;
int **parti;
int **imporTance,totOccurence;
//int *TempSelection;
float fractionI = 1.0;
int total_words;
int PartC,j;
int ChangeNumber,Changetotal_words;
int DBsum = 0;
//time_t t;
//srand((unsigned)time(&t));

PoissonContainer = (int *)calloc(total_nodes,sizeof(int));

randomPoisson(words,total_nodes,PoissonContainer);

total_words = total_nodes * words;
//printf("Tot B %d \n", total_words);
total_words +=  0.1 * total_words;
//printf("Tot A %d \n", total_words);

imporTance = (int **)calloc(3,sizeof(int *));
for(i = 0; i < 3; i++)
	imporTance[i] = (int *)calloc(number,sizeof(int));

/********This is for writing down********/
ArrangeImportance(number,imporTance[0],0);
ArrangeOccurrence(number,imporTance,fractionI,total_words);

ChangeNumber = number;
Changetotal_words = total_words;
ModelQueries(number, imporTance, total_words,TempSelection);

for (i = 0; i< total_nodes; i++)
{
parti = (int **)calloc(2,sizeof(int *));
for(j = 0; j < 2; j++)
	parti[j] = (int *)calloc(words,sizeof(int));
PartC = FormPartition(PoissonContainer[i] + 1,&ChangeNumber,parti,imporTance,TempSelection,&Changetotal_words);

(Computer+i)->NoInformation = PartC;
(Computer+i)->NoWords = PoissonContainer[i];
(Computer+i)->InformationSpace = (int **)calloc(2,sizeof(int *));
for(j= 0; j < 2; j++)
	(Computer+i)->InformationSpace[j] = (int *)calloc(PartC,sizeof(int));
for(j = 0; j < PartC; j ++)
	{
	(Computer+i)->InformationSpace[0][j] = parti[0][j];
	(Computer+i)->InformationSpace[1][j] = parti[1][j];
	}
for(j= 0; j < 2; j++)
	free(parti[j]);
free(parti);
}

for(i= 0; i < 2; i++)
	free(imporTance[i]);
free(imporTance);
free(PoissonContainer);
}


GenerateInformationProfileSimple(int *TempSelection,int number,int words, int total_nodes,PROFILE *Computer)
{
int i;
int **imporTance,totOccurence;
//int *TempSelection;
float fractionI = 1.0;
int total_words;
int PartC,j;
int ChangeNumber,Changetotal_words;
int DBsum = 0;
//time_t t;
//srand((unsigned)time(&t));

total_words = total_nodes * words;
//printf("Tot B %d \n", total_words);

imporTance = (int **)calloc(3,sizeof(int *));
for(i = 0; i < 3; i++)
	imporTance[i] = (int *)calloc(number,sizeof(int));

/********This is for writing down********/
ArrangeImportance(number,imporTance[0],0);
ArrangeOccurrence(number,imporTance,fractionI,total_words);

ModelQueries(number, imporTance, total_words,TempSelection);

for (i = 0; i< total_nodes; i++)
{
/******These are unnecessary steps only to maintain compatibility*****/
PartC = 1;
(Computer+i)->NoInformation = PartC;
(Computer+i)->NoWords = 1;
(Computer+i)->InformationSpace = (int **)calloc(2,sizeof(int *));
for(j= 0; j < 2; j++)
	(Computer+i)->InformationSpace[j] = (int *)calloc(PartC,sizeof(int));
for(j = 0; j < PartC; j ++)
	{
	(Computer+i)->InformationSpace[0][j] = TempSelection[i];
	(Computer+i)->InformationSpace[1][j] = 1;
	}
}


for(i= 0; i < 2; i++)
	free(imporTance[i]);
free(imporTance);
}


