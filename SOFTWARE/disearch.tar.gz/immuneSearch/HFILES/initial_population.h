

READFIRST(char *fname,int *TempData)
{
int NumberEdges,edge,initial,final;
int trash;
FILE *fp;
fp = fopen(fname,"r");
fscanf(fp,"%d",&NumberEdges);
//printf("No of Edges = %d ",NumberEdges);
for(edge=0; edge < NumberEdges; edge ++)
        {
                fscanf(fp,"%d",&initial);
                fscanf(fp,"%d",&final);
                TempData[initial]++;
                TempData[final]++;
        }

fclose(fp);
}

Place_in_Sorted_Position(int *Array, int noOfele, int Toinsert)
{
int i,j;
for(i = 1; i <= noOfele; i++)
	if(Toinsert < Array[i])
	  break;
for(j = noOfele; j >= i; j--)
	Array[j+1] = Array[j];
Array[i] = Toinsert;
}

READ(char *fname,PROFILE *Computer)
{
int NumberEdges,edge,initial,final;
int trash;
FILE *fp;
fp = fopen(fname,"r");
fscanf(fp,"%d",&NumberEdges);
for(edge=0; edge < NumberEdges; edge ++)
        {
                fscanf(fp,"%d",&initial);
                fscanf(fp,"%d",&final);
		Place_in_Sorted_Position(Computer[initial].neighborhood,Computer[initial].neighborhood[0],final);
                Computer[initial].neighborhood[0] ++;
                //Computer[initial].neighborhood[Computer[initial].neighborhood[0]] = final;
		Place_in_Sorted_Position(Computer[final].neighborhood,Computer[final].neighborhood[0],initial);
                Computer[final].neighborhood[0] ++;
                //Computer[final].neighborhood[Computer[final].neighborhood[0]] = initial;
                //fscanf(fp,"%d",&trash);
                //fscanf(fp,"%d",&trash);
        }

fclose(fp);
}

PRINT(PROFILE *Computer,int NumberNode)
{
int i,j;
        printf("\n\n");
for(i = 0; i < NumberNode; i++)
        {
        printf("%d - ",i);
	/*
        for(j = 0; j < WDLEN_I; j++)
        {
         printf("%d ",Computer[i].InformationSpace[j]);
         printf("%d |",Computer[i].searched[j]);
        }*/
	printf("%d :-",Computer[i].NoInformation);
	printf("%d :-",Computer[i].NoWords);
	for(j = 0; j < Computer[i].NoInformation; j++)
		printf("(%d,%d)",Computer[i].InformationSpace[0][j],Computer[i].InformationSpace[1][j]);
	printf(">>>");
	
        /*for(j = 0; j < WDLEN_S; j++)
         printf("%d |",Computer[i].SearchSpace[j]);*/
        for(j = 0; j <= Computer[i].neighborhood[0]; j++)
                printf("%d ",Computer[i].neighborhood[j]);
        printf("[");
                printf("%d,",Computer[i].MessageNo);
        printf("]");
	printf(" %d ", Computer[i].MessageVisited);
	printf("\n");
        }

/**********For TESTING*********
int CountP=0;
for(i = 0; i < NumberNode; i++)
                if(Computer[i].MessageNo > 0)
                        CountP ++;
printf("Query in %d Places",CountP);*/
}


float total_in_zipfs_law(int number,float fraction)
{
int i;
float total=0;
for ( i = 1; i<= number; i++)
	{ 
	total += (1/pow((float)i,fraction));
	/*printf("%3.2f",(1/(float)i));*/
	}
//printf("\n");
return(total); 
}

/*void ArrangeImportance(int number, int *imporTance,int first)
        {
        int i,j,remove, tag;
	FILE *fp;
	/*******First time only for the token arrangements********
	if(first)
	fp = fopen("Importance","w");
                for(i = 0; i < number; )
                        {
                        remove = random_generation() % number;
                        tag=0;
                        for(j = 0; j < i; j++)
                        if(remove == imporTance[j])
                        { tag = 1;
                          break;}
                        if (tag == 0)
                        {       
				imporTance[i]= remove;
				if(first)
					fprintf(fp,"%d %d \n ",i,imporTance[i]);
                                i++;
                        }
                        }

	if(first)
		fclose(fp);
        }*/

 void shuffle(int *Array, int Len)
{
	int i,j,k,n;

        for(i = Len; i>1; i--)
        {
        j = random_generation() % Len;
        k = i-1;
        n = Array[k];
        Array[k] = Array[j];
        Array[j] = n;

        }
}


void ArrangeImportance(int number, int *imporTance,int first)
        {
        int i,j,remove, tag;
        FILE *fp;
        /*******First time only for the token arrangements********/
        if(first)
        fp = fopen("Importance","w");
                for(i = 0; i < number; i++)
                                imporTance[i]= i;
		shuffle(imporTance,number);

        if(first)
	{
            for(i = 0; i < number; i++)
               	fprintf(fp,"%d %d \n ",i,imporTance[i]);
            fclose(fp);
	}
        }


/*Creates the initial configuration of the network
Create_Profile_computer(PROFILE *Computer, int number, int *imporTance, bool which, float fraction, int NumberNodes)
{
int total_words,i,j,I,J,K;

float TotalFrac,totOccur,spillover=0;
float temp;

if(which)
	total_words = NumberNodes * WDLEN_I;
else
	total_words = NumberNodes * WDLEN_S;
printf("WHICH - %d- %d",which,total_words);
//This is the total occurrence rate considering each occurs in zipfs law
TotalFrac = total_in_zipfs_law(number,fraction);
printf("Total = %f \n",TotalFrac);
spillover=0;
for(i=0;i<number; i++)
	{
		temp = pow((i+1),fraction);
		totOccur = total_words/(TotalFrac * temp) + spillover;
		spillover = totOccur - (int)totOccur;
		for(j = 0; j < (int)totOccur;)
			{
			I = random_generation()% NumberNodes;
			if(which)
			{ 
			K = random_generation()% WDLEN_I;
			if(Computer[I].InformationSpace[K] == 0)
				{
				j++;
				Computer[I].InformationSpace[K] = imporTance[i];
				}
			}
			else
			{ 
			K = random_generation()% WDLEN_S;
			if(Computer[I].SearchSpace[K] == 0)
                                {
                                j++;
                                Computer[I].SearchSpace[K] = imporTance[i];
                                }
			}
                        }



	}


}
*/


void InitializeSearch(PROFILE *Computer,int NumberNode)
{
int i,j,k;
for(i=0;i<NumberNode;i++)
		{
		for(j = 0; j < WDLEN_I; j++)
                	Computer[i].searched[j]=0;
                Computer[i].searchS=0;
                Computer[i].MessageVisited=0;
                Computer[i].MessageNo=0;
		}
		
}

void InitializeRound(PROFILE *Computer,int NumberNode)
{
int i,j,k;
for(i=0;i<NumberNode;i++)
		{
                Computer[i].GMessageVisited=0;
		}
		
}

int TrackDiffDistance(int *DArr, int Diffuse)
{
int i,j,k,l=-1,tag = 0;
if(Diffuse == 0)
	return(0);
for(i = -1,j = 0; j < Diffuse; )
	{
	tag = 0;
	for(k = j+1; k < Diffuse; k++)
		if(DArr[j] == DArr[k])
			{
			j = k;
			tag = 1;
			break;
			}
	if(tag == 0)
		{
		j++;
		i++;
		}
	
	}
l = TrackDiffDistance(DArr+1,Diffuse -1);
if(l +1 < i)
	return(l+1);
else
	return(i);
}

float InitialMessageQ(PROFILE *Computer,int NumberNode)
{
int i,j,k,Diff,TotDiff = 0, totMessage = 0;
float AvgDiff;
//printf(" --------\n" );
for(i=0;i<NumberNode;i++)
	{
		for(j = 0; j < Computer[i].MessageNo; j++)
		{	
			/*for(k = 0 ; k < Computer[i].Message_Q[j][0]; k ++)
				printf("%d  ", Computer[i].Message_Q[j][k]);*/
			if(Computer[i].Message_Q[j][0] != -1)
			{
			Diff = TrackDiffDistance(Computer[i].Message_Q[j]+1,Computer[i].Message_Q[j][0]);
			TotDiff += Diff;
			totMessage ++;
			//printf("|%d \n",Diff);
			}
			Computer[i].Message_Q[j][0] = 1;
        	        Computer[i].Message_Q[j][1] = i;
		}
	}

AvgDiff =(float)TotDiff/(float)totMessage;
//printf("%f %d %d --------\n", AvgDiff, TotDiff, totMessage);
return(AvgDiff);
}
