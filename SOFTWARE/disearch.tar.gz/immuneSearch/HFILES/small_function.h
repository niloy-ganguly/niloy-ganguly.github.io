


PRINT_INFORMATION(ESSIN *EssentialInformation, int i,int HowManyTimes,int randoM)
                {
                int k,j;
                if(randoM == 0)
                EssentialInformation[i].message = EssentialInformation[i].message/EssentialInformation[i].Turns;
                EssentialInformation[i].visit = EssentialInformation[i].visit/EssentialInformation[i].Turns;
                EssentialInformation[i].Turns = EssentialInformation[i].Turns/HowManyTimes;
                EssentialInformation[i].searchfound =  EssentialInformation[i].searchfound/HowManyTimes;
                EssentialInformation[i].BadV = EssentialInformation[i].BadV/HowManyTimes;
                EssentialInformation[i].Percentage = EssentialInformation[i].Percentage/HowManyTimes;
                printf("%3d  - %5d %5d %5d %5d ", EssentialInformation[i].Percentage, EssentialInformation[i].Turns,EssentialInformation[i].searchfound, EssentialInformation[i].message,EssentialInformation[i].visit);
                printf("\n");
                }


/*This function converts a decimal number to a binary string*/
int convert_to_binary(int no,int *a)
{
int i=0,j;
for(i=0;i<Wdsize;i++)
a[i]=0;
i=0;

while(no > 0)
        {
        a[i]= no%2;
        no  = no/2;
        i++;
        }
return(i);
}



/*This function checks the hamming distance between two binary arrays*/
checkdifference(int *aArray, int *bArray)
{
int i,diff=0;
for(i=0; i<Wdsize; i++)
        if(aArray[i] != bArray[i])
                diff++;
return(diff);
}

/*This function converts two numbers to binary and check their
hamming distance*/
int strike(int a, int b)
{
int aArray[Wdsize], bArray[Wdsize];
int aNo,bNo,diff;
aNo=convert_to_binary(a,aArray);
bNo=convert_to_binary(b,bArray);
diff=checkdifference(aArray,bArray);
return(diff);
}


int CheckDifference_D(PROFILE Peer, int *RandNode)
{
int J,j;
int HD=0;
        for(J=0;J<Peer.NoInformation;J++)
                {
		for(j = 2; j < RandNode[1]+2; j++)
			{
			if(RandNode[j] ==Peer.InformationSpace[0][J])
				{
				HD += Peer.InformationSpace[1][J];
				break;
				}
			}
		}
return(HD);
}



int Count_Message(PROFILE *Computer, int NumberNode)
{
int i,Count_M=0;
for(i = 0; i < NumberNode; i++)
                if(Computer[i].MessageNo > 0)
                        Count_M += Computer[i].MessageNo;
return(Count_M);
}

int Bad_Visit(PROFILE *Computer, int NumberNode)
{
int i,Count_M=0;
for(i = 0; i < NumberNode; i++)
if(Computer[i].MessageVisited > WDLEN_I)//At Most WDLEN_I should visit*****
        Count_M += Computer[i].MessageVisited - WDLEN_I;
return(Count_M);
}

int Good_Visit(PROFILE *Computer, int NumberNode, int numberOfTurns)
{
int i,Count_M=0;
for(i = 0; i < NumberNode; i++)
{
if(Computer[i].MessageVisited >=  WDLEN_I)//At Most WDLEN_I should visit******
	Count_M ++;
}
return(Count_M);
}


int ChooseQueryLength()
{
int i;
if(rand()%100 < 95)
        return(rand()%5 +1 );
else
        return(rand()%10 + 1);
}

ChooseQueryAndNode(int *RandomNode,int *TempSelection,int QL,int NumberNode,int total_words)
{
int i,j,Temp;
RandomNode[0] = random_generation() % NumberNode;
RandomNode[1] = QL;
for(i = 2; i < QL +2 ;)
	{
	Temp = TempSelection[random_generation()%total_words];
	for(j = 2; j < i; j++)
		if(Temp == RandomNode[i])
			continue;
	RandomNode[i] = Temp;
	i++;
	}
}





int SelectNoNeighbor_constprofile()
{
int NoNeighbour = 1; /****** At least one ********/
int i,k = 1,p;
int turn = 0;
                if(ALPHA <= 1.0)
                        {
                        //k = (int)(FRAC_Next * FRAC_Next/ALPHA);
                        k = (int)(1.9/ALPHA);
                        }
                else
                        {
                        turn = (int)ALPHA;
                        k = (int)((1.0)/(ALPHA - (float)turn));
                        }
                p = random_generation()%k;
                if(p == 0)
                         NoNeighbour++;
                NoNeighbour += turn;
//printf(" %d ",NoNeighbour);

return(NoNeighbour);
}
