
Produce(ESSIN *EssentialInformation, PROFILE *Computer, int **RandomNode,int NumberNode, int *No_of_Message, int What, int HowManyTimes)
{
int i,j,Count;
int TempStore;
float FullDiffAvg;
int Diff = 0;
int No_of_Message1;
//printf("\n\n Messages - %d \n\n", *No_of_Message);
TempStore = *No_of_Message;

EssentialInformation = (ESSIN *)calloc(PERC,sizeof(ESSIN)); // PERC to cover (10 - PERC + 1)*10 % to 100%
InitializeRound(Computer,NumberNode);
for(Count = 0; Count < HowManyTimes; Count++)
{
        //****************for RandomWalk ***************
        Proliferate(Computer,NumberNode,No_of_Message,RandomNode[Count],EssentialInformation,What);
         *No_of_Message = TempStore;
}
        printf(" Pcnt - Turn Search Message BadVisit \n");
        for(i = 0; i < PERC ; i++)
                {
                PRINT_INFORMATION(EssentialInformation,i,HowManyTimes,0);
                }

*No_of_Message = EssentialInformation[PERC - 2].visit;
No_of_Message1 = EssentialInformation[PERC - 2].message;
printf("\n\n Messages - %d \n\n", *No_of_Message);
free(EssentialInformation);
return(No_of_Message1);
}


TimeStepProduce(PROFILE *Computer, int **RandomNode,int NumberNode, int *No_of_Message, int What,
int HowManyTimes, int HowManyRound)
{
int i,j,Count;
int TempStore;
int RCount,Round;
int NoOfMessage=0,NoOfMessageRound=0;

//printf("\n\n Messages - %d \n\n", *No_of_Message);
TempStore = *No_of_Message;
int Search =0;

printf("Round\tSearch\tNoofMessage\n");
InitializeRound(Computer,NumberNode);
for(Count = 0,RCount = 1,Round = 1; Count < HowManyTimes; Count++,RCount++)
{
        //****************for RandomWalk ***************
        Search += SProliferate(Computer,NumberNode,No_of_Message,RandomNode[Count],What);
	NoOfMessage += *No_of_Message;
	NoOfMessageRound += *No_of_Message;
	if(RCount == HowManyRound)
	{
	printf("%d\t%5.2f\t%5.2f\n", Round, (float)((float)Search/(float)RCount), (float)((float)NoOfMessageRound/(float)RCount));
	Search = 0;
	NoOfMessageRound = 0;
	Round++;
	RCount = 0;
	}
         *No_of_Message = TempStore;
}

*No_of_Message = NoOfMessage/HowManyTimes;
printf("\n\n Messages - %d \n\n", *No_of_Message);
}
