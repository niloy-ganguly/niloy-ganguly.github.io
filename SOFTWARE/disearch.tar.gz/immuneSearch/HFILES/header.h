#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>

#define pi 3.1416
#define WDLEN_I 1
#define WDLEN_S 1
#define TURNS 50
#define MQueue 2000
#define PERC 9
#define RANDVARIANCE 20
#define SM_RANDVARIANCE 5
#define ALPHA 0.03 /* proliferation ratio*/


struct POINT{
int x;
int y;
};


typedef struct POINT POINT;

struct ESSIN{
int Turns;
int searchfound;
int message;
int visit;
int BadV;
int Percentage;
};


struct compProfile{
//int InformationSpace;
int **InformationSpace;
int NoInformation;
int NoWords;
int searched[WDLEN_I];
int Sused;
int SearchSpace[WDLEN_S];
int used;
int searchS;
int MessageVisited; 	/****How many message visits a peer ********/
int MessageNo;
int **Message_Q; 	/*Making it Dynamic*/
/**/
/**/
int *neighborhood;
int GMessageVisited;
};

int strike(int, int);
int searchCount=0;
int *RandomSequence; /* The first global*/
int PERCENT=10000;/*Amount of packet dropped */
int KEYWORD=1000;/*Number of possible keywords */
int Wdsize; 
int REAL;

int SCOUNT = 0;

typedef struct compProfile PROFILE;
typedef struct ESSIN ESSIN;
typedef int bool;

/********Complete Path Information *************/

float  PROLI_RATE = 0.5;
float  MUTAT_RATE = 0.5;
 

int random_generation(void)
{
int i,j,k;
double U1,U2;     /*here U1~u(0,1) and U2~u(0,1) and are independent*/
double X1,X2;       /*here X1 & X2 are Box_Miiller transformation no.*/
double temp1,temp2;
double cos1,sin2;

        U1=rand()%571+1;
        U1=U1/5570;
        U2=rand()%571;
        U2=U2/5570;

/*      printf("U1=%lf, U2=%lf\n",U1,U2);  */

        temp1=log(U1);
        /*printf("log=%lf\n",temp1);  */
        temp1=(-2)*temp1;
        temp1=sqrt(temp1);
        /*printf("sqrt=%lf\n",temp1);  */

        temp2=44/7;
        temp2=temp2*U2;
        /*printf("2PiU2=%lf\n",temp2);  */
        cos1=cos(temp2);
        /*printf("cos=%lf\n",cos1);   */
        sin2=sin(temp2);
        /*printf("sin=%lf\n",sin2);  */

        X1=temp1*cos1;
        X2=temp1*sin2;

        /*printf("X1=%lf :: X2=%lf\n",X1,X2);   */

        X1=X1*1000000;
        X2=X2*1000000;
        return((int)X1);
}

