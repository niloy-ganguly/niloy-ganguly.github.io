/********Complete Path Information *************/

int InPlace(PROFILE *Computer,int NumberNode,int No_of_Message, int *RandomNode)
{
int i,RandNode,ExactSearchProfile,Message;
int RandNeigh,AcRandNeigh;
RandNode = RandomNode[0];
Message = -1;
for(i=0; i < No_of_Message;i++ )
        {
        RandNeigh = random_generation()%Computer[RandNode].neighborhood[0];
        AcRandNeigh = Computer[RandNode].neighborhood[RandNeigh +1];
	if(Computer[AcRandNeigh].MessageNo < (Computer[AcRandNeigh].neighborhood[0] * MQueue))
                {
                Computer[AcRandNeigh].MessageNo++;
                }
        }
return(0);
}

/********changing for NEW Message = 1 & 0**********************/
int ProliInPlace(PROFILE *Computer,int NumberNode,int *No_of_Message,int *RandomNode)
{
int i,RandNode,ExactSearchProfile,Message;
int RandNeigh,AcRandNeigh;
RandNode = RandomNode[0];
*No_of_Message = Computer[RandNode].neighborhood[0];
for(i=0; i < *No_of_Message; )
        {
        AcRandNeigh = Computer[RandNode].neighborhood[i +1];
	if(Computer[AcRandNeigh].MessageNo < (Computer[AcRandNeigh].neighborhood[0] * MQueue))
                {
                Computer[AcRandNeigh].MessageNo++;
                i++;
                }
        }
}


int SelectNoNeighbor(PROFILE Peer, float FracHd)
{
int NoNeighbour = 1; /****** At least one *********/
int i,k,p;
    if(REAL)
	{
		k = (int)(FracHd*1000000*PROLI_RATE);
		//printf("%d = k",k); 
	for(i = 1; i < Peer.neighborhood[0]; i++)
		{
		p = rand()%1000000;
		if(p < k)
			 NoNeighbour++;
		}
	}
	else
	{
	int HD = (int)((1.0 - FracHd)*Wdsize);
                k = ceil(exp(HD) * ((float)Peer.neighborhood[0]/PROLI_RATE));
        for(i = 1; i < Peer.neighborhood[0]; i++)
                {
                p = random_generation()%k;
                if(p == 0)
                         NoNeighbour++;
                }

	}

return(NoNeighbour);
	
}

/*This algorithm randomize the free neighbors so that the
movement can be done randomly*/
Free_to_use(int *list, int list_length, int required)
        {
        int i,j,remove, tag,repitition = 0;
                for(i = 0; i < required; )
                        {
                        remove = random_generation() % list_length;
                        tag=0;
                        for(j = 0; j < i; j++)
                        if((remove == list[j]) && (repitition < 20)) /***** 20 is a good threshold*****/
                        { 
				tag = 1;
				repitition++; /*this is required for constant proliferation*/
                       		break;
			}
                        if (tag == 0)
                        {       list[i]= remove;
                                i++;
                        }
                        }
        }

/*****takes care of two cases constant proliferation and proliferation both without collision**********/
int ProliferateForward(PROFILE *Computer,int j, float FracHd)
{
//int i,ExactSearchProfile,Message;
int RandNeigh,AcRandNeigh,N,Anyhit;
int Check,Temp;
int *list,i;
	//N = SelectNoNeighbor(Computer[j],HD);
	if(( FracHd > 0.0) && (FracHd <= 1.0))
	{
	N = SelectNoNeighbor(Computer[j],FracHd);
	//printf("X");
	}
	else
	{
	if( FracHd > 1.0)
		N = 1;
	else
		{
		N = SelectNoNeighbor_constprofile();
	//	printf("%d",N);
		}
	}

	//printf("%d .",N);
	list = (int *)calloc(Computer[j].neighborhood[0],sizeof(int)); 
	Free_to_use(list, Computer[j].neighborhood[0],Computer[j].neighborhood[0]);
	Anyhit = 0;
	for(i = 0; Anyhit < N && i < Computer[j].neighborhood[0]; i++)
	{
        AcRandNeigh = Computer[j].neighborhood[list[i] +1]; /*- Use it if you sometimes decide to use Free*/
        //printf("%d -> %d ",j,AcRandNeigh);
        if((Computer[AcRandNeigh].MessageNo < (Computer[AcRandNeigh].neighborhood[0] * MQueue)) && (Computer[AcRandNeigh].MessageVisited < WDLEN_I))
                {
                Computer[AcRandNeigh].MessageNo++;
		Anyhit++;
                }
	
	}
	if(Anyhit)
		{
                	Computer[j].MessageNo--;   /*Decreased*/
		}
	else /*if no one can be proliferated till now*/                                                    
		{
		RandNeigh = random_generation()%Computer[j].neighborhood[0];                    
		AcRandNeigh = Computer[j].neighborhood[RandNeigh +1];                          
		if(Computer[AcRandNeigh].MessageNo < (Computer[AcRandNeigh].neighborhood[0] * MQueue))
		{ 
                Computer[AcRandNeigh].MessageNo++;   /*Increased*/
                	Computer[j].MessageNo--;   /*Decreased*/
		i++; /*one more time check*/
		}
		}
	free(list);
	return(abs(i-N));
}


int ProliColForward(PROFILE *Computer,int j, float FracHd)
{
//int i,ExactSearchProfile,Message;
int RandNeigh,AcRandNeigh,N,Anyhit;
int *list,i;
int Check;
int Temp;
	if(( FracHd >= 0.0) && (FracHd <= 1.0))
		N = SelectNoNeighbor(Computer[j],FracHd);
	else
	{
	if(( FracHd > 1.0) && (FracHd < 3.0)) /************Random walk********/
		N = 1;
	else
		{
		printf("\n Something Wrong %f \n", FracHd);
		if(FracHd > 3.0) /************Flood ********/
			N = Computer[j].neighborhood[0];
		else
			N = SelectNoNeighbor_constprofile();
		}
	}
        //printf("%d ",N);
        list = (int *)calloc(N,sizeof(int));
        Free_to_use(list, Computer[j].neighborhood[0],N);
        Anyhit = 0;
        for(i = 0; i < N; i++)
        {
        AcRandNeigh = Computer[j].neighborhood[list[i] +1];
	/**************Here for proliferation we need change --- change made ********/
	if(Computer[AcRandNeigh].MessageNo < (Computer[AcRandNeigh].neighborhood[0] * MQueue))
	{
        	Computer[AcRandNeigh].MessageNo++;
        	Anyhit++;
	}
        }
                if(Anyhit)
		{
                	Computer[j].MessageNo--;   /*Decreased*/
		}
        free(list);
	return(abs(i-N));
}

		



int Proliferate_Motion_Each_Turn(PROFILE *Computer,int NumberNode,int *No_of_message,int *No_of_visit, int *RandomNode, int What)
{
//int *imporTance;
int i,j,searchCount = 0;
int whichOne = 0;
int HD = 0;
float FracHd = 0;
int IniMessage; /**********It is a temporary solution *********/
if((What == 4) || (What == 5))
	FracHd = 2.0;
if(What == 6)/*************Flooding*******/
	FracHd = 4.0;
IniMessage = Count_Message(Computer,NumberNode);

shuffle(RandomSequence,NumberNode);
int Visit = 0;
for(i = 0; i < NumberNode; i++)
{
HD=0;
j = RandomSequence[i];
if(Computer[j].MessageNo > 0) /**********Drop a percentage ***************************/
{
if((PERCENT == 10000) || (random_generation()%PERCENT != 0) || (IniMessage <= PERCENT/2))
{
//printf("x");
/***********To calculate multiple packets visiting the same site *********/
		Computer[j].MessageVisited++;
		Computer[j].GMessageVisited++;
	/*****With the first in the queue - that is more logical **********/
	if(Computer[j].MessageVisited == 1)
		{
			if(REAL)
			HD = CheckDifference_D(Computer[j],RandomNode);
			else
			{
			HD = Wdsize - strike(Computer[j].InformationSpace[0][0],RandomNode[2]);
			//printf("HD - %d %d %d ",Computer[j].InformationSpace[0][0],RandomNode[0],HD);
			}
		}
	if(HD > 0)/************Exact Search ***********/
		{
			if(REAL)
				searchCount += HD;
			else
				{
				if(HD == Wdsize)
					searchCount ++;
				}

			Computer[j].searched[whichOne] = 1;//Not needed
		}
	if(What == 1 || What == 3)
		{
			if(REAL)
				FracHd = (float)HD/(float)Computer[j].NoWords;
			else
			{
				FracHd = (float)HD/(float)Wdsize;
				//printf("F -%d %d %5.2f ",HD,Wdsize,FracHd);
			}
		if(FracHd > 1)
			{
			printf("Something Wrong Frac - %f", FracHd);
			exit(0);
			}
		}
		if((What < 2) || (What == 4))
                	Visit += ProliferateForward(Computer,j, FracHd); /***********restricted******/
		else
			Visit += ProliColForward(Computer,j,FracHd);/******************simple************/
	}
	else
	{
		IniMessage--;
		Computer[j].MessageNo--;                                                        
	}		
        }
}
//free(imporTance);
*No_of_message=Count_Message(Computer,NumberNode);
*No_of_visit = *No_of_message + Visit;
return(searchCount);
}

/**What 0 = proliferation at constant rate without collision
	1 = affinity driven proliferation without collision
	2 = proliferation at constant rate with collision
	3 = affinity driven proliferation with collision
	4 = random walk without collision
	5 = random walk with collision
	6 = flooding **/

int Proliferate(PROFILE *Computer,int NumberNode,int *No_of_Message, int *RandNode, ESSIN *EssentialInformation, int What)
{
int i=0,j,k;
int numberOfTurns = 1;
int Search=0,SearchF;
int No_of_Visit; 
int InitialMessage = *No_of_Message;
int NoNodeVisited;
int  halfnMore = (10 - PERC + 1)*10;
int InitialVisit;
float NoDiff;

InitializeSearch(Computer,NumberNode);
/***********Doing both Proliferation and Random Walk in one shot*******/
if((What < 4) || (What == 6))
ProliInPlace(Computer,NumberNode,No_of_Message,RandNode); /*********Initial************/
else
InPlace(Computer,NumberNode,*No_of_Message,RandNode);

InitialMessage = *No_of_Message;
InitialVisit = *No_of_Message;
        //printf("\n\n Message = %d  Searc = %d\n\n", InitialMessage, Search);
while(1)
	{
			
//	PRINT(Computer,NumberNode);
	/******Proliferation at each turn **************/
        SearchF = Proliferate_Motion_Each_Turn(Computer,NumberNode,No_of_Message,&No_of_Visit,RandNode,What);
	if(*No_of_Message == 0)
		{
		printf("failure");
		break;
		}
	InitialMessage += *No_of_Message;
	InitialVisit += No_of_Visit; 	/***********Visit implies checking*******/
        Search += SearchF;
        numberOfTurns ++;
	NoNodeVisited=Good_Visit(Computer,NumberNode);
	//printf("NodeVisited - %d Message = %d\n ",NoNodeVisited,*No_of_Message);
	/*coverage from 50 to 100 percent*/
	while(NoNodeVisited >= (halfnMore * NumberNode/100))
		{
		(EssentialInformation + i)->Turns +=  numberOfTurns;
		(EssentialInformation + i)->searchfound += Search;
		(EssentialInformation +i)->message += InitialMessage;
		(EssentialInformation +i)->visit += InitialVisit; /********New lines********/
		(EssentialInformation + i)->BadV += Bad_Visit(Computer,NumberNode);
		(EssentialInformation + i)->Percentage += (NoNodeVisited * 100)/NumberNode;
		i++;
		halfnMore += 10;
		}
	if (NoNodeVisited == NumberNode)
		break;
	}
return(Search);
}

int SProliferate(PROFILE *Computer,int NumberNode,int *No_of_Message, int *RandNode, int What)
{
int i=0,j;
int numberOfTurns = 1;
int Search=0,SearchF;
int InitialMessage = *No_of_Message;
int NoNodeVisited;
int  halfnMore = (10 - PERC + 1)*10;
int No_of_Visit; 

InitializeSearch(Computer,NumberNode);
//***********Doing both Proliferation and Random Walk in one shot*******
if((What < 4) || (What == 6))
	ProliInPlace(Computer,NumberNode,No_of_Message,RandNode);
else
	InPlace(Computer,NumberNode,*No_of_Message,RandNode);

InitialMessage = *No_of_Message;
        //printf("\n\n Message = %d  Searc = %d\n\n", InitialMessage, Search);
while(numberOfTurns < TURNS)
        {
        //PRINT(Computer,NumberNode);
        SearchF = Proliferate_Motion_Each_Turn(Computer,NumberNode,No_of_Message,&No_of_Visit,RandNode,What);
        InitialMessage += *No_of_Message;
        Search += SearchF;
        numberOfTurns ++;
        }
*No_of_Message = InitialMessage/TURNS;
return(Search);
}
