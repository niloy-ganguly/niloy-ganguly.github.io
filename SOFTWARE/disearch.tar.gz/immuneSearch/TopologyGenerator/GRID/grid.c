#include <stdio.h>

main(int argc, char **argv)
{
int i,NumberNode,height,width; 
FILE *fp;
if(argc != 5)
        {
        printf("FileName, Number of nodes, height, width \n");
        exit(0);
        }

NumberNode = atoi(argv[2]);
height  = atoi(argv[3]);
width = atoi(argv[4]);

if(height * width != NumberNode)
	{
	printf(" Something Wrong \n");
	exit(0);
	}
fp = fopen(argv[1],"w");
fprintf(fp,"% d \n", 2*NumberNode);
for(i = 0; i < height*width; i++)
	{
	if((i+1)/width > i/width)
	fprintf(fp,"%d %d\n", i, (i + 1 - width));
	else
	fprintf(fp,"%d %d\n", i, (i + 1));
	fprintf(fp,"%d %d\n", i, (i + width)%NumberNode);
	}
fclose(fp);
}
